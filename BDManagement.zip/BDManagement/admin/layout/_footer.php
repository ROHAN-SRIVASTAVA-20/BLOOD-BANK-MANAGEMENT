<footer class="nav navbar-fixed-bottom">
            <b>Made By: GROUP 1</a></b>
            <br>
            &COPY;GROUP1
</footer>



</body>
</html>
