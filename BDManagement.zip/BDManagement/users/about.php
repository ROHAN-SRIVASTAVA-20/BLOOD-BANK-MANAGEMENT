<?php
$title="About Us";$setAboutActive="active";
include 'layout/_header.php';

include 'layout/navbar.php';
?>

<div class="container">
    <div class="row">
        <div class="col-md-10">
            <a href="#" id="Heading">About Us</a>
            <p>We are a non-profitable organization which aims to provide a better and easier way to find the required blood needed
            at the time. </p>
        </div>
    </div>
</div>

<?php include 'layout/_footer.php'; ?>

