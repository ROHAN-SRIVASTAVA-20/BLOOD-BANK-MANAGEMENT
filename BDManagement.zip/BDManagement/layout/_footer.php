<footer class="foter">
            <b>Made By: GROUP 1 </a></b>
            <br>
            &COPY;GROUP1
</footer>



</body>
</html>
